jQuery(document).ready(function($) {
    $('#post-cat-val').select2();
    $('#post-tag-val').select2();
    $('#prod-cat-val').select2();
    $('#prod-tag-val').select2();
});

  
 