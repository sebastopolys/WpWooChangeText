<?php

echo "AJAX TEST";